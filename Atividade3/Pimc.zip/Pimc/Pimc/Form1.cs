﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtPeso.Text = String.Empty; 
            txtAltura.Text = String.Empty; 
            txtIMC.Text = String.Empty; 
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                double peso = Convert.ToDouble(txtPeso.Text);
                double altura = Convert.ToDouble(txtAltura.Text);

                
                if (peso == 0 || altura == 0)
                {
                    MessageBox.Show("O peso e a altura não podem ser zero.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return; 
                }

                
                double imc = peso / (altura * altura);

               
                txtIMC.Text = imc.ToString("F2");

                if (imc < 18.5)
                {
                    MessageBox.Show("Magreza");
                }
                else if (imc > 18.5 && imc < 24.9)
                {
                    MessageBox.Show("Normal");
                }
                else if (imc >= 25.0 && imc < 29.9)
                {
                    MessageBox.Show("Sobrepeso");
                }
                else if (imc >= 30.0 && imc < 39.9)
                {
                    MessageBox.Show("Obesidade");
                }
                else
                {
                    MessageBox.Show("Obesidade Grave");
                }
            }
            catch (FormatException)
            {
                MessageBox.Show("Por favor, insira valores válidos para peso e altura.", "Erro de Formato", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro: " + ex.Message, "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

            }
        }

    }

