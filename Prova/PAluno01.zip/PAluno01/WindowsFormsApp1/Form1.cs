﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {

            double[,] notas = new double[5, 3];
            string auxiliar = "";
            double media = 0;
            double mediageral = 0;
            int aluno = 0;
            int professor = 0;
            string saida = "";
            int p1, p2, p3;


            for (int i = 0; i < 5; i++)
            {
                media = 0;

                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Aluno {aluno + i + 1} - Professor: {professor + j + 1}", "Entrada de notas");


                    if (!double.TryParse(auxiliar, out notas[i, j]) ||
                        notas[i, j] < 0 || notas[i, j] > 10)
                    {
                        MessageBox.Show("Nota inválida! Digite um número entre 0 e 10.",
                            "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        j--; // Refaz a pergunta da nota atual

                    }
                    else
                    {
                        media += notas[i, j];
                        mediageral = media / 5;
                    }

                    //listNota.Items.Add($"Nota do aluno {i + 1}: " + $"{notas[i,j]}");
                }
                media = media / 3;

                listNota.Items.Add($"Nota do aluno {i + 1}: {notas} Media do aluno: {media} Nota do professor {{p1 + 1}}\" + $\"Nota do professor {{p2 + 1}}\" + $\"Notas do professor\"{{p3 + 1}}\"");

            }


        }
            //MessageBox.Show(saida, "Média dos alunos");
            //"Aluno {i + 1} Nota Professor {j + 1} + {notas[i, j]} Nota Professor {j + 2} + {notas[i, j]} Nota Professor {j + 3} + {notas[i, j]}
            //+ $"Nota do professor {p1 + 1}" + $"Nota do professor {p2 + 1}" + $"Notas do professor"{p3 + 1}")


        
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            listNota.Items.Clear();
        }
    }
}
