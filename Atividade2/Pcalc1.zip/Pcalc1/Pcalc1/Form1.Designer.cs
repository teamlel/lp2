﻿namespace Pcalc1
{
    partial class Form1
    {
        /// <summary>
        /// Variável de designer necessária.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpar os recursos que estão sendo usados.
        /// </summary>
        /// <param name="disposing">true se for necessário descartar os recursos gerenciados; caso contrário, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código gerado pelo Windows Form Designer

        /// <summary>
        /// Método necessário para suporte ao Designer - não modifique 
        /// o conteúdo deste método com o editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtResultado = new System.Windows.Forms.TextBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.btnDividir = new System.Windows.Forms.Button();
            this.btnMultiplicar = new System.Windows.Forms.Button();
            this.btnSubtrair = new System.Windows.Forms.Button();
            this.btnSoma = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.txtNmr2 = new System.Windows.Forms.TextBox();
            this.txtNmr1 = new System.Windows.Forms.TextBox();
            this.r = new System.Windows.Forms.Label();
            this.lblNmr1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // txtResultado
            // 
            this.txtResultado.Enabled = false;
            this.txtResultado.HideSelection = false;
            this.txtResultado.Location = new System.Drawing.Point(143, 126);
            this.txtResultado.Name = "txtResultado";
            this.txtResultado.Size = new System.Drawing.Size(100, 26);
            this.txtResultado.TabIndex = 23;
            this.txtResultado.EnabledChanged += new System.EventHandler(this.txtResultado_EnabledChanged);
            this.txtResultado.TextChanged += new System.EventHandler(this.txtResultado_TextChanged);
            // 
            // Label1
            // 
            this.Label1.AutoSize = true;
            this.Label1.Location = new System.Drawing.Point(37, 129);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(82, 20);
            this.Label1.TabIndex = 22;
            this.Label1.Text = "Resultado";
            // 
            // btnDividir
            // 
            this.btnDividir.Location = new System.Drawing.Point(262, 183);
            this.btnDividir.Name = "btnDividir";
            this.btnDividir.Size = new System.Drawing.Size(57, 46);
            this.btnDividir.TabIndex = 21;
            this.btnDividir.Text = "/";
            this.btnDividir.UseVisualStyleBackColor = true;
            this.btnDividir.Click += new System.EventHandler(this.btnDividir_Click);
            // 
            // btnMultiplicar
            // 
            this.btnMultiplicar.Location = new System.Drawing.Point(186, 183);
            this.btnMultiplicar.Name = "btnMultiplicar";
            this.btnMultiplicar.Size = new System.Drawing.Size(57, 46);
            this.btnMultiplicar.TabIndex = 20;
            this.btnMultiplicar.Text = "*";
            this.btnMultiplicar.UseVisualStyleBackColor = true;
            this.btnMultiplicar.Click += new System.EventHandler(this.btnMultiplicar_Click);
            // 
            // btnSubtrair
            // 
            this.btnSubtrair.Location = new System.Drawing.Point(114, 183);
            this.btnSubtrair.Name = "btnSubtrair";
            this.btnSubtrair.Size = new System.Drawing.Size(57, 46);
            this.btnSubtrair.TabIndex = 19;
            this.btnSubtrair.Text = "  -";
            this.btnSubtrair.UseVisualStyleBackColor = true;
            this.btnSubtrair.Click += new System.EventHandler(this.btnSubtrair_Click);
            // 
            // btnSoma
            // 
            this.btnSoma.Location = new System.Drawing.Point(41, 183);
            this.btnSoma.Name = "btnSoma";
            this.btnSoma.Size = new System.Drawing.Size(57, 46);
            this.btnSoma.TabIndex = 18;
            this.btnSoma.Text = "+";
            this.btnSoma.UseVisualStyleBackColor = true;
            this.btnSoma.Click += new System.EventHandler(this.btnSoma_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(288, 113);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(129, 46);
            this.btnSair.TabIndex = 17;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(288, 50);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(129, 47);
            this.btnLimpar.TabIndex = 16;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // txtNmr2
            // 
            this.txtNmr2.Location = new System.Drawing.Point(143, 81);
            this.txtNmr2.Name = "txtNmr2";
            this.txtNmr2.Size = new System.Drawing.Size(100, 26);
            this.txtNmr2.TabIndex = 15;
            this.txtNmr2.Validated += new System.EventHandler(this.txtNmr2_Validated);
            // 
            // txtNmr1
            // 
            this.txtNmr1.Location = new System.Drawing.Point(143, 44);
            this.txtNmr1.Name = "txtNmr1";
            this.txtNmr1.Size = new System.Drawing.Size(100, 26);
            this.txtNmr1.TabIndex = 14;
            this.txtNmr1.Validated += new System.EventHandler(this.txtNmr1_Validated);
            // 
            // r
            // 
            this.r.AutoSize = true;
            this.r.Location = new System.Drawing.Point(37, 84);
            this.r.Name = "r";
            this.r.Size = new System.Drawing.Size(78, 20);
            this.r.TabIndex = 13;
            this.r.Text = "Numero 2";
            // 
            // lblNmr1
            // 
            this.lblNmr1.AutoSize = true;
            this.lblNmr1.Location = new System.Drawing.Point(37, 47);
            this.lblNmr1.Name = "lblNmr1";
            this.lblNmr1.Size = new System.Drawing.Size(78, 20);
            this.lblNmr1.TabIndex = 12;
            this.lblNmr1.Text = "Numero 1";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(475, 305);
            this.Controls.Add(this.txtResultado);
            this.Controls.Add(this.Label1);
            this.Controls.Add(this.btnDividir);
            this.Controls.Add(this.btnMultiplicar);
            this.Controls.Add(this.btnSubtrair);
            this.Controls.Add(this.btnSoma);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.txtNmr2);
            this.Controls.Add(this.txtNmr1);
            this.Controls.Add(this.r);
            this.Controls.Add(this.lblNmr1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        internal System.Windows.Forms.TextBox txtResultado;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.Button btnDividir;
        internal System.Windows.Forms.Button btnMultiplicar;
        internal System.Windows.Forms.Button btnSubtrair;
        internal System.Windows.Forms.Button btnSoma;
        internal System.Windows.Forms.Button btnSair;
        internal System.Windows.Forms.Button btnLimpar;
        internal System.Windows.Forms.TextBox txtNmr2;
        internal System.Windows.Forms.TextBox txtNmr1;
        internal System.Windows.Forms.Label r;
        internal System.Windows.Forms.Label lblNmr1;
    }
}

