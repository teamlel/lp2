﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc1
{
    public partial class Form1 : Form
    {

        double valor1;
        double valor2;
        double resultado;

        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNmr1.Text = String.Empty;
            txtNmr2.Text = String.Empty;
            txtResultado.Text = String.Empty;
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            double valor1 = double.Parse(txtNmr1.Text);
            double valor2 = double.Parse(txtNmr2.Text);

            double resultado = valor1 + valor2;   

            txtResultado.Text = resultado.ToString();
        }

        private void txtResultado_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSubtrair_Click(object sender, EventArgs e)
        {
             valor1 = double.Parse(txtNmr1.Text);
             valor2 = double.Parse(txtNmr2.Text);

             resultado = valor1 - valor2;

            txtResultado.Text = resultado.ToString();
        }

        private void btnMultiplicar_Click(object sender, EventArgs e)
        {
             valor1 = double.Parse(txtNmr1.Text);
             valor2 = double.Parse(txtNmr2.Text);

             resultado = valor1 * valor2;

            txtResultado.Text = resultado.ToString();
        }

        private void btnDividir_Click(object sender, EventArgs e)
        {
             

            if (valor2 == 0)
            {
                
                MessageBox.Show("0 não pode ser utilizado em divisão, reveja o númreo 2");
                txtNmr2.Focus();
                txtNmr2.Clear();
                txtResultado.Clear();

            }
            else
            {
                resultado = valor1 / valor2;
                txtResultado.Text = resultado.ToString();
            }
           
    }

        private void txtResultado_EnabledChanged(object sender, EventArgs e)
        {

        }

        private void txtNmr1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNmr1.Text, out valor1))
            {
                MessageBox.Show("Número 1 inválido");
                txtNmr1.Focus();
                txtNmr1.Clear();
            }
        }

        private void txtNmr2_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtNmr2.Text, out valor2))
            {
                MessageBox.Show("Número 2 inválido");
                txtNmr2.Focus();
                txtNmr2.Clear();
            }
        }
    }
}
