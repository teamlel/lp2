﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void exercício1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmEx1>().Count() > 0)
            {
                Application.OpenForms["FrmEx1"].BringToFront(); // form existe traz ele para a frente
            }
            else
            {
                FrmEx1 obj1 = new FrmEx1(); // crio o objeto do novo formulario
                obj1.MdiParent = this;
                obj1.WindowState = FormWindowState.Maximized;
                obj1.Show();
            }
        }

        private void exercício2ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmEx2>().Count() > 0)
            {
                Application.OpenForms["FrmEx2"].BringToFront(); // form existe traz ele para a frente
            }
            else
            {
                FrmEx2 obj1 = new FrmEx2(); // crio o objeto do novo formulario
                obj1.MdiParent = this;
                obj1.WindowState = FormWindowState.Maximized;
                obj1.Show();
            }
        }

        private void exercício3ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmEx3>().Count() > 0)
            {
                Application.OpenForms["FrmEx3"].BringToFront(); // form existe traz ele para a frente
            }
            else
            {
                FrmEx3 obj1 = new FrmEx3(); // crio o objeto do novo formulario
                obj1.MdiParent = this;
                obj1.WindowState = FormWindowState.Maximized;
                obj1.Show();
            }
        }

        private void exercício4ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmEx4>().Count() > 0)
            {
                Application.OpenForms["FrmEx4"].BringToFront(); // form existe traz ele para a frente
            }
            else
            {
                FrmEx4 obj1 = new FrmEx4(); // crio o objeto do novo formulario
                obj1.MdiParent = this;
                obj1.WindowState = FormWindowState.Maximized;
                obj1.Show();
            }
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
