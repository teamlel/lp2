﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PLoops
{
    public partial class FrmEx2 : Form
    {
        public FrmEx2()
        {
            InitializeComponent();
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            try
            {
                int N = int.Parse(textBox1.Text);

                if (N <= 0)
                {
                    MessageBox.Show("Digite um número inteiro maior que zero.");
                    return;
                }

                double H = 0.0;

                for (int i = 1; i <= N; i++)
                {
                    H += 1.0 / i;
                }

                MessageBox.Show($"O número H é: {H:F4}", "Resultado");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro: insira um número válido.\n" + ex.Message, "Erro");
            }
        }

    }
}
