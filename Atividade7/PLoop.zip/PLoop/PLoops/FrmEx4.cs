﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace PLoops
{
    public partial class FrmEx4 : Form
    {
        public FrmEx4()
        {
            InitializeComponent();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnCalc_Click(object sender, EventArgs e)
        {
            try
            {
                string nome = txtNome.Text;
                string matricula = txtMatricula.Text;
                int producao = int.Parse(txtProd.Text);
                decimal salarioBase = decimal.Parse(txtSal.Text);
                decimal gratificacao = decimal.Parse(txtGrat.Text);

                int B = producao >= 100 ? 1 : 0;
                int C = producao >= 120 ? 1 : 0;
                int D = producao >= 150 ? 1 : 0;

                decimal bonus = salarioBase * (0.05m * B + 0.10m * C + 0.10m * D);
                decimal salarioBruto = salarioBase + bonus + gratificacao;

                // Aplicar restrição
                if (salarioBruto > 7000)
                {
                    if (!(producao >= 150 && gratificacao > 0))
                    {
                        salarioBruto = 7000;
                    }
                }

                MessageBox.Show($"Funcionário: {nome}\nMatrícula: {matricula}\nSalário Bruto: R$ {salarioBruto:F2}", "Resultado");
            }
            catch (Exception ex)
            {
                MessageBox.Show("Erro ao calcular. Verifique os dados inseridos.\n" + ex.Message, "Erro");
            }
        }


        private void txtGrat_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtSal_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtProd_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtNome_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
