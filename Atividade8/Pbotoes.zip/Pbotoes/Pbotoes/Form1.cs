﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;


namespace Pbotoes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            for (int i = 0; i < vetor.Length; i++)
            {
                auxiliar = Interaction.InputBox($"Digite o {i}º número", "Entrada de dados");

                if (auxiliar == "")
                {
                    MessageBox.Show("Operação cancelada pelo usuário.", "Cancelado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    return; 
                }


                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número inválido!");
                    i--;
                }
            }
            Array.Reverse(vetor);
            auxiliar = "";

            foreach (int x in vetor)
            {
                auxiliar += x+"\n";
            }
            MessageBox.Show(auxiliar);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            double[,] notas = new double[20, 3];
            string auxiliar = "";
            double media = 0;
            string saida = "";

            for (int i = 0; i < 20; i++)
            {
                media = 0;
                for (int j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox($"Digite a {j + 1}ª nota do aluno {i + 1}", "Entrada de notas");

                    // ✅ Se clicar em Cancelar
                    if (auxiliar == "")
                    {
                        MessageBox.Show("Operação cancelada pelo usuário.", "Cancelado", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        return; // Interrompe imediatamente
                    }

                    // Validação da nota
                    if (!double.TryParse(auxiliar, out notas[i, j]) || notas[i, j] < 0 || notas[i, j] > 10)
                    {
                        MessageBox.Show("Nota inválida! Digite um número entre 0 e 10.", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        j--; // Refaz a pergunta da nota atual
                    }
                    else
                    {
                        media += notas[i, j];
                    }
                }

                media = media / 3;
                saida += $"Aluno {i + 1}: Média: {media:N2}\n";
            }

            MessageBox.Show(saida, "Médias dos alunos");
        }


        private void button4_Click(object sender, EventArgs e)
        {
            frmExe4 obj4 = new frmExe4();
            obj4.Show();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            frmExe5 obj5 = new frmExe5();
            obj5.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            
            ArrayList alunos = new ArrayList()
    {
        "Ana", "André", "Beatriz", "Camila", "João",
        "Joana", "Otávio", "Marcelo", "Pedro", "Thais"
    };

           
            alunos.Remove("Otávio");

            // Exibir no console
            Console.WriteLine("Alunos (sem Otávio):");
            foreach (string nome in alunos)
            {
                Console.WriteLine(nome);
            }

            MessageBox.Show("Lista exibida no console.", "Concluído", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

    }
}
