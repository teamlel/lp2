﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ptestemetodos
{
    public partial class frmExercicio3: Form
    {
        public frmExercicio3()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string texto1 = textBox1.Text;
            string texto2 = textBox2.Text;

            //remove todas as ocorrências de texto1 em texto2
            string resultado = texto2.Replace(texto1, "");

            //exibe o resultado no txtResultado
            textBox1.Text = resultado;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string txt1 = textBox1.Text;
            char[] textoArray = txt1.ToCharArray();
            Array.Reverse(textoArray);
            string textoInvertindo = new string(textoArray);
            textBox1.Text = textoInvertindo;
        }
    }
}
