﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace Ptestemetodos
{
    public partial class frmExercicio2 : Form
    {
        public frmExercicio2()
        {
            InitializeComponent();
        }

        // Verifica se o texto dos TextBox1 e TextBox2 são iguais
        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == textox2.Text)
            {
                MessageBox.Show("Os textos são iguais.");
            }
            else
            {
                MessageBox.Show("Os textos são diferentes.");
            }
        }

        // Copia o texto de TextBox1 e insere no meio de TextBox2
        private void button2_Click(object sender, EventArgs e)
        {
            string text1 = textBox1.Text;
            string text2 = textBox2.Text;

            // Verifica se TextBox2 não está vazio e calcula a posição para inserir
            if (!string.IsNullOrEmpty(text2))
            {
                int middle = text2.Length / 2;
                string result = text2.Substring(0, middle) + text1 + text2.Substring(middle);
                textBox2.Text = result;
            }
            else
            {
                MessageBox.Show("TextBox2 está vazio.");
            }
        }

        // Insere dois asteriscos no meio do texto de TextBox1 e coloca o resultado em TextBox2
        private void button3_Click(object sender, EventArgs e)
        {
            string text1 = textBox1.Text;

            if (!string.IsNullOrEmpty(text1))
            {
                int middle = text1.Length / 2;
                string result = text1.Substring(0, middle) + "**" + text1.Substring(middle);
                textBox2.Text = result;
            }
            else
            {
                MessageBox.Show("TextBox1 está vazio.");
            }
        }
    }
}
